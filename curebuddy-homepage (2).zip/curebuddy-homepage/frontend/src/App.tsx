// src/App.tsx
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";

// Layouts
import Sidebar from "./components/Sidebar";
import AdminSidebar from "./components/AdminSidebar";


// Doctor Registration Pages
import DoctorPersonalInfoPage from "./pages/DoctorPersonalInfoPage";
import DoctorProfessionalInfoPage from "./pages/DoctorProfessionalInfoPage";
import DoctorClinicHospitalPage from "./pages/DoctorClinicHospitalPage";
import DoctorConsultationPage from "./pages/DoctorConsultationPage";
import DoctorDocumentUploadPage from "./pages/DoctorDocumentUploadPage";
import RegistrationSubmittedPage from "./pages/RegistrationSubmittedPage";

// Admin Pages
import AdminDashboardPage from "./pages/admin/AdminDashboardPage";
import DoctorListPage from "./pages/admin/DoctorListPage";
import DoctorDetailsPage from "./pages/admin/DoctorDetailPage";
import AdminApprovedDoctorsPage from "./pages/admin/AdminApprovedDoctorsPage";
import AdminPendingDoctorsPage from "./pages/admin/AdminPendingDoctorsPage";
import AdminRejectedDoctorsPage from "./pages/admin/AdminRejectedDoctorsPage";
import AdminAppointmentsPage from "./pages/admin/AdminAppointmentsPage";


// Layout Wrappers
const AdminLayout = ({ children }: { children: React.ReactNode }) => (
  <div className="flex">
    <AdminSidebar />
    <div className="flex-1 p-4">{children}</div>
  </div>
);

const DoctorLayout = ({ children }: { children: React.ReactNode }) => (
  <div className="flex">
    <Sidebar />
    <div className="flex-1 p-4">{children}</div>
  </div>
);

const App = () => {
  return (
    <Router>
      <Routes>
        
        {/* Doctor Registration Routes */}
        <Route
          path="/"
          element={
            <DoctorLayout>
              <Navigate to="/personal" />
            </DoctorLayout>
          }
        />
        <Route path="/personal" element={<DoctorLayout><DoctorPersonalInfoPage /></DoctorLayout>} />
        <Route path="/professional" element={<DoctorLayout><DoctorProfessionalInfoPage /></DoctorLayout>} />
        <Route path="/clinic" element={<DoctorLayout><DoctorClinicHospitalPage /></DoctorLayout>} />
        <Route path="/consultation" element={<DoctorLayout><DoctorConsultationPage /></DoctorLayout>} />
        <Route path="/documents" element={<DoctorLayout><DoctorDocumentUploadPage /></DoctorLayout>} />
        <Route path="/registration-submitted" element={<DoctorLayout><RegistrationSubmittedPage /></DoctorLayout>} />

        {/* Admin Routes */}
        <Route path="/admin" element={<Navigate to="/admin/dashboard" />} />
        <Route path="/admin/dashboard" element={<AdminLayout><AdminDashboardPage /></AdminLayout>} />
        <Route path="/admin/doctors" element={<AdminLayout><DoctorListPage /></AdminLayout>} />
        <Route path="/admin/doctors/:id" element={<AdminLayout><DoctorDetailsPage /></AdminLayout>} />
        <Route path="/admin/doctors/approved" element={<AdminLayout><AdminApprovedDoctorsPage /></AdminLayout>} />
        <Route path="/admin/doctors/pending" element={<AdminLayout><AdminPendingDoctorsPage /></AdminLayout>} />
        <Route path="/admin/doctors/rejected" element={<AdminLayout><AdminRejectedDoctorsPage /></AdminLayout>} />
        <Route path="/admin/appointments" element={<AdminLayout><AdminAppointmentsPage /></AdminLayout>} />
      </Routes>
    </Router>
  );
};

export default App;

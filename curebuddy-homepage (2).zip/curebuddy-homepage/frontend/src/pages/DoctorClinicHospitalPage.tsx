import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useDoctor } from "../context/DoctorContext";
import Topbar from "../components/Topbar";

const DoctorClinicHospitalPage: React.FC = () => {
  const navigate = useNavigate();
  const { doctorData, updateDoctorData } = useDoctor();

  const [hospitalName, setHospitalName] = useState("");
  const [address, setAddress] = useState("");
  const [city, setCity] = useState("");
  const [state, setState] = useState("");
  const [pincode, setPincode] = useState("");

  useEffect(() => {
    if (doctorData.hospitalName) setHospitalName(doctorData.hospitalName);
    if (doctorData.address) setAddress(doctorData.address);
    if (doctorData.city) setCity(doctorData.city);
    if (doctorData.state) setState(doctorData.state);
    if (doctorData.pincode) setPincode(doctorData.pincode);
  }, [doctorData]);

  const handleNext = () => {
    if (!hospitalName || !address || !city || !state || !pincode) {
      alert("Please fill all fields.");
      return;
    }

    updateDoctorData({ hospitalName, address, city, state, pincode });
    navigate("/consultation");
  };

  const handleBack = () => {
    navigate("/professional");
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <div className="flex flex-col flex-1 overflow-hidden">
        <Topbar />
        <main className="p-6 overflow-y-auto">
          <h2 className="text-2xl font-bold mb-6 text-gray-800">Clinic / Hospital Info</h2>

          <div className="bg-white p-6 rounded-lg shadow-md max-w-3xl">
            <form className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">Hospital / Clinic Name</label>
                <input
                  type="text"
                  value={hospitalName}
                  onChange={(e) => setHospitalName(e.target.value)}
                  className="w-full border border-gray-300 rounded px-3 py-2"
                  placeholder="e.g. City Care Hospital"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">City</label>
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full border border-gray-300 rounded px-3 py-2"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">State</label>
                <input
                  type="text"
                  value={state}
                  onChange={(e) => setState(e.target.value)}
                  className="w-full border border-gray-300 rounded px-3 py-2"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">Pincode</label>
                <input
                  type="text"
                  value={pincode}
                  onChange={(e) => setPincode(e.target.value)}
                  className="w-full border border-gray-300 rounded px-3 py-2"
                  required
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium mb-1">Address</label>
                <textarea
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full border border-gray-300 rounded px-3 py-2"
                  rows={3}
                  required
                />
              </div>
            </form>

            <div className="flex justify-between mt-6">
              <button
                type="button"
                className="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600"
                onClick={handleBack}
              >
                ← Back
              </button>
              <button
                type="button"
                className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700"
                onClick={handleNext}
              >
                Next →
              </button>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default DoctorClinicHospitalPage;

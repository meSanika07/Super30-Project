import React, { useState } from "react";
import { useDoctor } from "../context/DoctorContext";
import Topbar from "../components/Topbar";
import { useNavigate } from "react-router-dom";

const DoctorDocumentUploadPage: React.FC = () => {
  const { doctorData, updateDoctorData } = useDoctor();
  const navigate = useNavigate();
  const [submitting, setSubmitting] = useState(false);

  const handleFileChange = (field: string, file: File | null) => {
    updateDoctorData({ [field]: file });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);

    // TEMP: Replace with actual userId from auth when integrated
    const userId = "6659b3b5f1c23a77e0a91234";

    const formData = new FormData();
    formData.append("userId", userId);
    formData.append("name", doctorData.name);
    formData.append("email", doctorData.email);
    formData.append("gender", doctorData.gender);
    formData.append("dob", doctorData.dob);
    formData.append("phone", doctorData.phone);
    formData.append("specialization", doctorData.specialization);
    formData.append("university", doctorData.university);
    formData.append("licenseNo", doctorData.licenseNo);
    formData.append("qualification", doctorData.qualification);
    formData.append("yearsOfExperience", String(doctorData.yearsOfExperience));
    formData.append("hospitalName", doctorData.hospitalName);
    formData.append("address", doctorData.address);
    formData.append("city", doctorData.city);
    formData.append("state", doctorData.state);
    formData.append("pincode", doctorData.pincode);
    formData.append("fee", String(doctorData.fee));
    formData.append("availableDays", JSON.stringify(doctorData.availableDays));
    formData.append("availableTimeSlots", JSON.stringify(doctorData.availableTimeSlots));

    if (doctorData.profilePicture) formData.append("profilePicture", doctorData.profilePicture);
    if (doctorData.degreeCertificate) formData.append("degreeCertificate", doctorData.degreeCertificate);
    if (doctorData.medicalLicense) formData.append("medicalLicense", doctorData.medicalLicense);
    if (doctorData.idProof) formData.append("idProof", doctorData.idProof);

    try {
      const res = await fetch("http://localhost:5000/api/doctors/register", {
        method: "POST",
        body: formData,
      });

      const result = await res.json();
      if (result.success) {
        navigate("/registration-submitted");
      } else {
        alert("Registration failed: " + result.message);
      }
    } catch (error) {
      console.error("Submission Error:", error);
      alert("Error submitting the form.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="flex h-screen bg-[#F9FAFF]">
      <div className="flex flex-col flex-1 overflow-auto">
        <Topbar />
        <main className="flex-1 p-8">
          <h2 className="text-2xl font-bold mb-8 text-[#2C2C2C]">Upload Your Documents</h2>

          <form
            className="bg-white rounded-2xl shadow-lg p-10 max-w-3xl w-full mx-auto space-y-8"
            onSubmit={handleSubmit}
          >
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Profile Picture</label>
              <input
                type="file"
                accept="image/*"
                onChange={(e) => handleFileChange("profilePicture", e.target.files?.[0] || null)}
                className="w-full border border-gray-300 rounded px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Degree Certificate</label>
              <input
                type="file"
                accept=".pdf,image/*"
                onChange={(e) => handleFileChange("degreeCertificate", e.target.files?.[0] || null)}
                className="w-full border border-gray-300 rounded px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Medical License</label>
              <input
                type="file"
                accept=".pdf,image/*"
                onChange={(e) => handleFileChange("medicalLicense", e.target.files?.[0] || null)}
                className="w-full border border-gray-300 rounded px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">ID Proof</label>
              <input
                type="file"
                accept=".pdf,image/*"
                onChange={(e) => handleFileChange("idProof", e.target.files?.[0] || null)}
                className="w-full border border-gray-300 rounded px-3 py-2"
              />
            </div>

            <div className="pt-6 text-right">
              <button
                type="submit"
                disabled={submitting}
                className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 transition"
              >
                {submitting ? "Submitting..." : "Submit Registration"}
              </button>
            </div>
          </form>
        </main>
      </div>
    </div>
  );
};

export default DoctorDocumentUploadPage;

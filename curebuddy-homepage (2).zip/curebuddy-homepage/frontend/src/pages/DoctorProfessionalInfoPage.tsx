// src/pages/DoctorProfessionalInfoPage.tsx
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useDoctor } from "../context/DoctorContext";
import Topbar from "../components/Topbar";

const DoctorProfessionalInfoPage: React.FC = () => {
  const navigate = useNavigate();
  const { updateDoctorData } = useDoctor();

  const [specialization, setSpecialization] = useState("");
  const [university, setUniversity] = useState("");
  const [qualification, setQualification] = useState("");
  const [yearsOfExperience, setYearsOfExperience] = useState("");
  const [licenseNo, setLicenseNo] = useState("");

  const handleNext = () => {
    updateDoctorData({ specialization, university, qualification, yearsOfExperience: Number(yearsOfExperience), licenseNo });
    navigate("/clinic");
  };

  const handleBack = () => {
    navigate("/");
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <div className="flex flex-col flex-1 overflow-hidden">
        <Topbar />
        <main className="p-6 overflow-y-auto">
          <h2 className="text-xl font-semibold mb-4">Professional Info</h2>

          <div className="bg-white p-6 rounded-lg shadow-md max-w-4xl">
            <form className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">Specialization</label>
                <input type="text" value={specialization} onChange={(e) => setSpecialization(e.target.value)} className="w-full border border-gray-300 rounded px-3 py-2" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">University</label>
                <input type="text" value={university} onChange={(e) => setUniversity(e.target.value)} className="w-full border border-gray-300 rounded px-3 py-2" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Qualification</label>
                <input type="text" value={qualification} onChange={(e) => setQualification(e.target.value)} className="w-full border border-gray-300 rounded px-3 py-2" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Years of Experience</label>
                <input type="number" value={yearsOfExperience} onChange={(e) => setYearsOfExperience(e.target.value)} min="0" className="w-full border border-gray-300 rounded px-3 py-2" />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium mb-1">License No.</label>
                <input type="text" value={licenseNo} onChange={(e) => setLicenseNo(e.target.value)} className="w-full border border-gray-300 rounded px-3 py-2" />
              </div>
            </form>

            <div className="flex justify-between mt-6">
              <button className="bg-gray-300 px-4 py-2 rounded text-sm" onClick={handleBack}>← Back</button>
              <button className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 transition" onClick={handleNext}>Next →</button>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default DoctorProfessionalInfoPage;
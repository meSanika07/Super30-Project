import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";

const DoctorDetailsPage: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [doctor, setDoctor] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
  const fetchDoctor = async () => {
    try {
      const res = await fetch(`http://localhost:5000/api/doctors/${id}`);
      const data = await res.json();

      if (data.success) {
        setDoctor(data.data);  // ✅ Only set if success is true
      } else {
        console.error(data.message);
        setDoctor(null);       // doctor not found
      }

    } catch (err) {
      console.error("Failed to fetch doctor details:", err);
      setDoctor(null);
    } finally {
      setLoading(false);
    }
  };

  fetchDoctor();
}, [id]);



  const handleStatusUpdate = async (status: "Approve" | "Reject") => {
    try {
      await fetch(`http://localhost:5000/api/doctors/${id}/${status.toLowerCase()}`, {
        method: "PATCH",
      });
      alert(`Doctor ${status}d successfully`);
      navigate("/admin/doctors");
    } catch (err) {
      alert(`Failed to ${status} doctor.`);
    }
  };

  if (loading) return <div className="p-8">Loading...</div>;
  if (!doctor) return <div className="p-8">Doctor not found.</div>;

  return (
    <div className="p-8 bg-gray-100 min-h-screen">
      <div className="max-w-4xl mx-auto bg-white p-8 rounded shadow space-y-6">
        <h2 className="text-2xl font-bold text-gray-800">Doctor Profile</h2>

        {/* Profile Photo */}
        {doctor.documentInfo?.profilePhoto && (
          <div className="mb-4">
            <img
              src={doctor.documentInfo.profilePhoto}
              alt="Doctor"
              className="w-24 h-24 rounded-full object-cover"
            />
          </div>
        )}

        {/* Personal Info */}
        <section>
          <h3 className="text-xl font-semibold mb-2 text-blue-700">Personal Information</h3>
          <p><strong>Name:</strong> {doctor.name}</p>
          <p><strong>Email:</strong> {doctor.email}</p>
          <p><strong>Phone:</strong> {doctor.phone}</p>
          <p><strong>Gender:</strong> {doctor.gender}</p>
          <p><strong>Birthday:</strong> {doctor.dob ? new Date(doctor.dob).toLocaleDateString() : "N/A"}</p>
        </section>

        {/* Professional Info */}
        <section>
          <h3 className="text-xl font-semibold mb-2 text-blue-700">Professional Information</h3>
          <p><strong>Qualification:</strong> {doctor.professionalInfo?.qualification}</p>
          <p><strong>Specialization:</strong> {doctor.professionalInfo?.specialization}</p>
          <p><strong>Years of Experience:</strong> {doctor.professionalInfo?.yearsOfExperience} years</p>
          <p><strong>License Number:</strong> {doctor.professionalInfo?.licenseNo}</p>
        </section>

        {/* Hospital Info */}
        <section>
          <h3 className="text-xl font-semibold mb-2 text-blue-700">Clinic / Hospital Details</h3>
          <p><strong>Name:</strong> {doctor.hospitalInfo?.name}</p>
          <p><strong>City:</strong> {doctor.hospitalInfo?.city}</p>
          <p><strong>Address:</strong> {doctor.hospitalInfo?.address}</p>
          <p><strong>Pincode:</strong> {doctor.hospitalInfo?.pincode}</p>
        </section>

        {/* Consultation Info */}
        <section>
          <h3 className="text-xl font-semibold mb-2 text-blue-700">Consultation</h3>
          <p><strong>Fee:</strong> ₹{doctor.consultationInfo?.fee}</p>
          <p><strong>Available Days:</strong> {(doctor.consultationInfo?.availableDays || []).join(", ")}</p>
          <p><strong>Time Slots:</strong> {(doctor.consultationInfo?.availableTimeSlots || []).join(", ")}</p>
        </section>

        {/* Uploaded Documents */}
        <section>
          <h3 className="text-xl font-semibold mb-2 text-blue-700">Uploaded Documents</h3>

          {doctor.documentInfo?.degreeCertificate ? (
            <p>
              <strong>Degree Certificate:</strong>{" "}
              <a
                href={doctor.documentInfo.degreeCertificate}
                target="_blank"
                rel="noreferrer"
                className="text-blue-600 underline"
              >
                View
              </a>
            </p>
          ) : (
            <p className="text-gray-500">Degree Certificate not uploaded</p>
          )}

          {doctor.documentInfo?.license ? (
            <p>
              <strong>Medical License:</strong>{" "}
              <a
                href={doctor.documentInfo.license}
                target="_blank"
                rel="noreferrer"
                className="text-blue-600 underline"
              >
                View
              </a>
            </p>
          ) : (
            <p className="text-gray-500">Medical License not uploaded</p>
          )}

          {doctor.documentInfo?.idProof ? (
            <p>
              <strong>ID Proof:</strong>{" "}
              <a
                href={doctor.documentInfo.idProof}
                target="_blank"
                rel="noreferrer"
                className="text-blue-600 underline"
              >
                View
              </a>
            </p>
          ) : (
            <p className="text-gray-500">ID Proof not uploaded</p>
          )}
        </section>

        {/* Action Buttons */}
        <div className="flex gap-4 pt-6">
          <button
            onClick={() => handleStatusUpdate("Approve")}
            className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
          >
            Approve
          </button>
          <button
            onClick={() => handleStatusUpdate("Reject")}
            className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700"
          >
            Reject
          </button>
        </div>
      </div>
    </div>
  );
};

export default DoctorDetailsPage;

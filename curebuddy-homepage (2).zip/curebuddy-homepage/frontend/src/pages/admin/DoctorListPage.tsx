import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

interface Doctor {
  _id: string;
  name: string;
  email: string;
  phone: string;
  status: string;
  professionalInfo?: {
    specialization?: string;
  };
}

const DoctorListPage: React.FC = () => {
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
  fetch("http://localhost:5000/api/admin/doctors")
    .then((res) => res.json())
    .then((data) => setDoctors(data.data)) // ✅ Note the `.data` here
    .catch((err) => console.error("Failed to fetch doctors", err))
    .finally(() => setLoading(false));
}, []);



  const getStatusStyle = (status: string) => {
    switch (status) {
      case "approved":
        return "text-green-600 font-semibold";
      case "pending":
        return "text-yellow-600 font-semibold";
      case "rejected":
        return "text-red-600 font-semibold";
      default:
        return "";
    }
  };

  if (loading) return <div className="p-8">Loading doctors...</div>;

  return (
    <div className="p-8 bg-gray-100 min-h-screen">
      <div className="max-w-6xl mx-auto bg-white p-8 rounded shadow">
        <h2 className="text-2xl font-bold mb-6 text-gray-800">All Doctors</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left border">
            <thead className="bg-gray-100">
              <tr>
                <th className="p-4 border">Name</th>
                <th className="p-4 border">Email</th>
                <th className="p-4 border">Phone</th>
                <th className="p-4 border">Specialization</th>
                <th className="p-4 border">Status</th>
                <th className="p-4 border">Action</th>
              </tr>
            </thead>
            <tbody>
              {doctors.map((doctor) => (
                <tr key={doctor._id} className="hover:bg-gray-50">
                  <td className="p-4 border">{doctor.name}</td>
                  <td className="p-4 border">{doctor.email}</td>
                  <td className="p-4 border">{doctor.phone || "N/A"}</td>
                  <td className="p-4 border">{doctor.professionalInfo?.specialization || "N/A"}</td>
                  <td className={`p-4 border ${getStatusStyle(doctor.status)}`}>
                    {doctor.status}
                  </td>
                  <td className="p-4 border">
                    <button
                      onClick={() => navigate(`/admin/doctors/${doctor._id}`)}
                      className="text-blue-600 hover:underline"
                    >
                      View
                    </button>
                  </td>
                </tr>
              ))}
              {doctors.length === 0 && (
                <tr>
                  <td colSpan={6} className="p-4 text-center">
                    No doctors found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default DoctorListPage;

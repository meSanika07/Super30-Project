import React, { useEffect, useState } from "react";

interface Appointment {
  _id: string;
  doctorName: string;
  patientName: string;
  dateTime: string;
  department: string;
  patientImg?: string;
  doctorImg?: string;
}

const AdminAppointmentsPage: React.FC = () => {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("http://localhost:5000/api/admin/appointments")
      .then((res) => res.json())
      .then((data) => setAppointments(data))
      .catch((err) => console.error("Error fetching appointments:", err))
      .finally(() => setLoading(false));
  }, []);

  return (
    <main className="flex-1 bg-gray-100 p-10">
      <h1 className="text-2xl font-bold mb-6 text-gray-800">All Appointments</h1>

      {loading ? (
        <p>Loading...</p>
      ) : (
        <div className="bg-white rounded-lg shadow p-6 overflow-x-auto">
          <table className="min-w-full text-sm text-left">
            <thead className="bg-gray-100 text-gray-700">
              <tr>
                <th className="p-3">#</th>
                <th className="p-3">Patient</th>
                <th className="p-3">Department</th>
                <th className="p-3">Date & Time</th>
                <th className="p-3">Doctor</th>
              </tr>
            </thead>
            <tbody className="text-gray-800">
              {appointments.map((appt, index) => (
                <tr key={appt._id} className="border-b hover:bg-gray-50">
                  <td className="p-3">{index + 1}</td>
                  <td className="p-3 flex items-center gap-2">
                    <img
                      src={appt.patientImg || "/doctor-profile.jpg"}
                      alt="patient"
                      className="w-8 h-8 rounded-full object-cover"
                    />
                    {appt.patientName}
                  </td>
                  <td className="p-3">{appt.department}</td>
                  <td className="p-3">{appt.dateTime}</td>
                  <td className="p-3 flex items-center gap-2">
                    <img
                      src={appt.doctorImg || "/doctor-profile.jpg"}
                      alt="doctor"
                      className="w-8 h-8 rounded-full object-cover"
                    />
                    {appt.doctorName}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </main>
  );
};

export default AdminAppointmentsPage;

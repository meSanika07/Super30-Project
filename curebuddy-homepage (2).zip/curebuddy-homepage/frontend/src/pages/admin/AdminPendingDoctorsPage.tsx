import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

interface Doctor {
  _id: string;
  name: string;
  email: string;
  phone: string;
  gender: string;
  status: string;
}

const AdminPendingDoctorsPage: React.FC = () => {
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [processingId, setProcessingId] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchPendingDoctors = async () => {
      try {
        const res = await fetch("http://localhost:5000/api/admin/doctors");
        const data = await res.json();
        const pending = (data.data || []).filter((doc: Doctor) => doc.status === "pending");
        setDoctors(pending);
      } catch (err) {
        console.error("Failed to fetch pending doctors", err);
      } finally {
        setLoading(false);
      }
    };

    fetchPendingDoctors();
  }, []);

  const handleAction = async (id: string, action: "approve" | "reject") => {
    setProcessingId(id);
    try {
      await fetch(`http://localhost:5000/api/doctors/${id}/${action}`, {
        method: "PATCH",
      });
      setDoctors((prev) => prev.filter((doc) => doc._id !== id));
    } catch {
      alert(`Failed to ${action} doctor.`);
    } finally {
      setProcessingId(null);
    }
  };

  const filteredDoctors = doctors.filter((doc) =>
    `${doc.name} ${doc.email}`.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-6 min-h-screen bg-gray-100">
      <h1 className="text-3xl font-bold text-gray-800 mb-4">Pending Doctor Approvals</h1>

      <input
        type="text"
        placeholder="Search by name or email..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        className="w-full max-w-md px-4 py-2 mb-6 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
      />

      {loading ? (
        <div className="text-gray-500 text-lg">Loading doctors...</div>
      ) : (
        <div className="overflow-x-auto bg-white rounded-lg shadow border border-gray-200">
          <table className="min-w-full text-sm text-left">
            <thead className="bg-blue-50 text-blue-700 uppercase text-xs">
              <tr>
                <th className="p-4 border">Name</th>
                <th className="p-4 border">Email</th>
                <th className="p-4 border">Phone</th>
                <th className="p-4 border">Gender</th>
                <th className="p-4 border text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="text-gray-800">
              {filteredDoctors.map((doctor, index) => (
                <tr
                  key={doctor._id}
                  className={`border-b ${
                    index % 2 === 0 ? "bg-white" : "bg-gray-50"
                  } hover:bg-blue-50 transition`}
                >
                  <td
                    className="p-4 border text-blue-600 font-medium cursor-pointer"
                    onClick={() => navigate(`/admin/doctors/${doctor._id}`)}
                  >
                    {doctor.name}
                  </td>
                  <td className="p-4 border">{doctor.email}</td>
                  <td className="p-4 border">{doctor.phone}</td>
                  <td className="p-4 border">{doctor.gender}</td>
                  <td className="p-4 border text-center space-x-2">
                    <button
                      onClick={() => handleAction(doctor._id, "approve")}
                      className="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded-full text-xs"
                      disabled={processingId === doctor._id}
                    >
                      {processingId === doctor._id ? "Processing..." : "Approve"}
                    </button>
                    <button
                      onClick={() => handleAction(doctor._id, "reject")}
                      className="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded-full text-xs"
                      disabled={processingId === doctor._id}
                    >
                      {processingId === doctor._id ? "Processing..." : "Reject"}
                    </button>
                  </td>
                </tr>
              ))}
              {filteredDoctors.length === 0 && (
                <tr>
                  <td colSpan={5} className="text-center p-6 text-gray-500">
                    No pending doctors found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default AdminPendingDoctorsPage;

import React from "react";
import { Link } from "react-router-dom";

const doctors = Array.from({ length: 10 }, (_, i) => ({
  id: i,
  name: "Dr. Richard James",
  specialization: "General physician",
  available: true,
  image: "/Doctor.png", // Make sure this image is in your public folder
}));

const DoctorSection = () => {
  return (
    <section className="py-12 px-6 bg-white text-center">
      <h2 className="text-3xl font-bold text-gray-900 mb-2">Top Doctors to Book</h2>
      <p className="text-gray-500 mb-10">
        Simply browse through our extensive list of trusted doctors.
      </p>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
        {doctors.map((doctor) => (
          <Link to="/doctor-profile" key={doctor.id}>
            <div className="cursor-pointer bg-white border border-gray-200 rounded-xl shadow-md p-4 hover:shadow-lg transition">
              <img
                src={doctor.image}
                alt={doctor.name}
                className="w-24 h-24 object-cover rounded-full mx-auto mb-4"
              />
              {doctor.available && (
                <p className="text-green-600 text-sm font-medium mb-1">
                  ● Available
                </p>
              )}
              <h3 className="text-lg font-semibold text-gray-900">{doctor.name}</h3>
              <p className="text-sm text-gray-500">{doctor.specialization}</p>
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
};

export default DoctorSection;

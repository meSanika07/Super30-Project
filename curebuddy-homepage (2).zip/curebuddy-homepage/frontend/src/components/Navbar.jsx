import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <nav className="flex justify-between items-center py-4 px-6 shadow-md bg-white">
      <div className="flex items-center space-x-2">
        <img src="/Logo.jpg" alt="CureBuddy Logo" className="h-8 w-auto" />
        <span className="text-xl font-bold text-[#1f3bb3]">CureBuddy</span>
      </div>
      <ul className="flex items-center space-x-6 text-sm text-black">
        {/* ✅ Link to Home */}
        <li><Link to="/" className="hover:text-blue-500">HOME</Link></li>

        {/* Other Links */}
        <li><Link to="/alldoctors" className="hover:text-blue-500">ALL DOCTORS</Link></li>
        <li><Link to="/about" className="hover:text-blue-500">ABOUT</Link></li>
        <li><Link to="/contact" className="hover:text-blue-500">CONTACT</Link></li>
        <li>
          <Link to="/profile">
            <button className="ml-4 bg-[#5d6bfa] hover:bg-[#4453d7] text-white px-5 py-1.5 rounded-full text-sm">
            LogIn/SignUp
            </button>
          </Link>
        </li>
      </ul>
    </nav>
  );
};

export default Navbar;

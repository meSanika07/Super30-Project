import React, { useState } from "react";

const days = ["Mon", "TUE", "WED", "THU", "FRI", "SAT", "SUN"];
const times = [
  "8.00 am", "8.30 am", "9.00 am", "9.30 am",
  "10.00 am", "10.30 am", "11.00 am", "11.30 am"
];

const DoctorConsultationForm = () => {
  const [selectedDays, setSelectedDays] = useState<string[]>([]);
  const [selectedTimes, setSelectedTimes] = useState<string[]>([]);

  const toggleDay = (day: string) => {
    setSelectedDays((prev) =>
      prev.includes(day) ? prev.filter((d) => d !== day) : [...prev, day]
    );
  };

  const toggleTime = (time: string) => {
    setSelectedTimes((prev) =>
      prev.includes(time) ? prev.filter((t) => t !== time) : [...prev, time]
    );
  };
  

  return (
    <div className="p-6 bg-white shadow-md rounded-xl w-full max-w-4xl mx-auto mt-10">
      <h2 className="text-2xl font-semibold mb-8 text-gray-800 text-center">
        Consultation info
      </h2>

      <div className="mb-10">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Consultation Fee
        </label>
        <input
          type="text"
          placeholder="Fee"
          className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      <div>
        <h3 className="text-lg font-medium text-gray-700 mb-5">
          Select Available Day and Time
        </h3>

        {/* Days */}
        <div className="flex flex-wrap gap-4 mb-6">
          {days.map((day) => (
            <button
              key={day}
              onClick={() => toggleDay(day)}
              className={`px-6 py-3 rounded-full border transition ${
                selectedDays.includes(day)
                  ? "bg-blue-500 text-white border-blue-500"
                  : "bg-white text-gray-800 border-gray-300"
              } shadow-sm text-sm font-semibold`}
            >
              {day}
            </button>
          ))}
        </div>

        {/* Time Slots */}
        <div className="flex flex-wrap gap-4">
          {times.map((time) => (
            <button
              key={time}
              onClick={() => toggleTime(time)}
              className={`px-5 py-2 rounded-full border transition ${
                selectedTimes.includes(time)
                  ? "bg-blue-500 text-white border-blue-500"
                  : "bg-white text-gray-800 border-gray-300"
              } shadow-sm text-sm font-medium`}
            >
              {time}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DoctorConsultationForm;

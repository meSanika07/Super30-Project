  import React, { useState, useEffect, useRef } from "react";
  import { FaMapMarkerAlt, FaSearch } from "react-icons/fa";
  import { Link } from "react-router-dom";
  import { useNavigate } from "react-router-dom";


  import { FaArrowRight, FaUserPlus, FaFacebookF, FaTwitter, FaInstagram } from "react-icons/fa";
  import heroImage from "../assets/Doctor.png";
  import doctorImage from "../assets/image 2222.jpg";
  import logo from "../assets/Logo.jpg";


  const HomePage = () => {
    const doctors = [
    {
      id: 0,
      name: "Dr. Rajeev Nair",
      specialization: "General Physician",
      image: "/doctor-hero.jpg",
      available: true,
    },
    {
      id: 1,
      name: "Dr. Priya Mehta",
      specialization: "General Physician",
    image: "/Dr. Priya Mehta.png",
      available: true,
    },
    {
      id: 2,
      name: "Dr. Richard James",
      specialization: "General Physician",
    image: "/Dr. Richard James.jpeg",
      available: true,
    },
    {
      id: 3,
      name: "Dr. Arjun Verma",
      specialization: "General Physician",
      image: "/Dr. Arjun Verma.jpg",
      available: true,
    },
    {
      id: 4,
      name: "Dr. Ramesh Patil",
      specialization: "General Physician",
      image: "/Dr. Ramesh Patil.jpg",
      available: true,
    },
    {
      id: 5,
      name: "Dr. Vivek Choudhary",
      specialization: "General Physician",
      image: "/Dr. Vivek Choudhary.jpg",
      available: true,
    },
    {
      id: 6,
      name: "Dr. Shreya Nair",
      specialization: "General Physician",
      image: "/Dr. Shreya Nair.jpg",
      available: true,
    },
    {
      id: 7,
      name: "Dr. Sandeep Joshi",
      specialization: "General Physician",
      image: "/Dr. Sandeep Joshi.jpg",
      available: true,
    },
    {
      id: 8,
      name: "Dr. Swati Kulkarni",
      specialization: "General Physician",
      image: "/Dr. Swati Kulkarni.jpg",
      available: true,
    },
    {
      id: 9,
      name: "Dr. Nikhil Deshmukh",
      specialization: "General Physician",
      image: "/Dr. Nikhil Deshmukh.png",
      available: true,
    },
  ];

    const doctorSectionRef = useRef(null);
    const [locationInput, setLocationInput] = useState("");
  const navigate = useNavigate();


    const handleLocationSearch = () => {
      if (locationInput.trim() !== "") {
        navigate(`/alldoctors?location=${encodeURIComponent(locationInput.trim())}`);
      }
    };

    return (
      <>
        {/* Navbar */}
        <nav className="flex justify-between items-center py-4 px-6 shadow-md bg-white">
          <div className="flex items-center space-x-2">
            <img src="/Logo.jpg" alt="CureBuddy Logo" className="h-8 w-auto" />
            <span className="text-xl font-bold text-[#1f3bb3]">CureBuddy</span>
          </div>
          <ul className="flex items-center space-x-6 text-sm text-black">
            <li>
              <Link to="/" className="hover:text-blue-500">HOME</Link>
            </li>
            <li>
              <Link to="/alldoctors" className="hover:text-blue-500">ALL DOCTORS</Link>
            </li>
            <li>
              <Link to="/about" className="hover:text-blue-500">ABOUT</Link>
            </li>
            <Link to="/contact" className="hover:text-blue-500">CONTACT</Link>


            <li>
              <Link to="/profile">
                <button className="ml-4 bg-[#5d6bfa] hover:bg-[#4453d7] text-white px-5 py-1.5 rounded-full text-sm">
                  LogIn/SignUp
                </button>
              </Link>
            </li>
          </ul>
        </nav>

        {/* Hero Section */}
        <section className="w-full bg-white px-8 py-20 lg:px-24">
          <div className="flex flex-col lg:flex-row items-center justify-between max-w-7xl mx-auto gap-10">
            <div className="lg:w-1/2">
              <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6 leading-snug">
                Take Charge Of Your <br /> Health – Book Instantly.
              </h1>
              <p className="text-gray-600 text-base lg:text-lg mb-8">
                Your Health, Your Schedule. Secure Your Appointment Online In Minutes! <br />
                Trusted Care, Seamless Booking – We’re Here When You Need Us Most.
              </p>
            <button
    onClick={() => doctorSectionRef.current.scrollIntoView({ behavior: "smooth" })}
    className="bg-blue-500 text-white px-20 py-6 rounded-full text-lg font-semibold flex items-center gap-5 hover:bg-blue-600 transition"
  >
    Book appointment <FaArrowRight />
  </button>

            </div>
            <div className="lg:w-1/2 flex justify-center">
              <img
                src={heroImage}
                alt="Healthcare hero"
                className="w-[400px] h-[500px] object-cover rounded-lg shadow-lg"
              />
            </div>
          </div>
        </section>

        {/* Search Bar */}
        <div className="flex justify-center items-center py-8 bg-white font-sans">
          <div className="flex items-center bg-[#eaf0ff] rounded-xl px-6 py-4 w-[1150px] h-[65px]">
            <div className="flex items-center gap-2 text-gray-800 font-medium">
              <FaMapMarkerAlt />
              <span>Pune</span>
            </div>
            <div className="h-6 w-px bg-gray-400 mx-6"></div>
            <div className="flex items-center gap-2 flex-1 text-gray-700">
              <FaSearch />
              <input
                type="text"
                placeholder="Search doctors, hospital, etc."
                className="bg-transparent outline-none border-none w-full text-base"
              />
            </div>
          </div>

          <button
      onClick={handleLocationSearch}
      className="bg-blue-500 text-white px-6 py-3 rounded hover:bg-blue-600"
    >
      Enter
    </button>
        </div>

        {/* Doctor Section */}
<section ref={doctorSectionRef} className="py-12 px-6 bg-white text-center">
  <h2 className="text-3xl font-bold text-gray-900 mb-2">Top Doctors to Book</h2>
  <p className="text-gray-500 mb-10">Simply browse through our extensive list of trusted doctors.</p>

  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
    {doctors.map((doctor) => (
      <Link to={`/doctor-profile/${doctor.id}`} key={doctor.id}>
        <div className="cursor-pointer bg-white border border-gray-200 rounded-xl shadow-md p-4 hover:shadow-lg transition">
          <img
            src={doctor.image}
            alt={doctor.name}
            className="w-24 h-24 object-cover rounded-full mx-auto mb-4"
          />
          {doctor.available && (
            <p className="text-green-600 text-sm font-medium mb-1">
              ● Available
            </p>
          )}
          <h3 className="text-lg font-semibold text-gray-900">{doctor.name}</h3>
          <p className="text-sm text-gray-500">{doctor.specialization}</p>
        </div>
      </Link>
    ))}
  </div>
</section>



      {/* <section ref={doctorSectionRef} className="py-12 px-6 bg-white text-center">

          <h2 className="text-3xl font-bold text-gray-900 mb-2">Top Doctors to Book</h2>
          <p className="text-gray-500 mb-10">Simply browse through our extensive list of trusted doctors.</p>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
            {doctors.map((doctor) => (
              <Link to="/doctor-profile" key={doctor.id}>
                <div className="cursor-pointer bg-white border border-gray-200 rounded-xl shadow-md p-4 hover:shadow-lg transition">
                  <img
                    src={doctor.image}
                    alt={doctor.name}
                    className="w-24 h-24 object-cover rounded-full mx-auto mb-4"
                  />
                  {doctor.available && (
                    <p className="text-green-600 text-sm font-medium mb-1">
                      ● Available
                    </p>
                  )}
                  <h3 className="text-lg font-semibold text-gray-900">{doctor.name}</h3>
                  <p className="text-sm text-gray-500">{doctor.specialization}</p>
                </div>
              </Link>
            ))}
          </div>
        </section> */}

        {/* CTA Section */}
        <section className="bg-[#586DF6] text-white rounded-xl p-10 mx-4 md:mx-16 my-10">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="md:w-1/2 text-center md:text-left">
              <h3 className="text-3xl md:text-4xl font-extrabold leading-snug">
                Book Appointment <br />
                With 100+ Trusted Doctors
              </h3>
              <button className="mt-6 bg-white text-[#586DF6] px-6 py-3 text-sm md:text-base rounded-full flex items-center gap-2 hover:bg-gray-100 transition">
                <FaUserPlus /> Create account
              </button>
            </div>
            <div className="md:w-1/2 flex justify-center">
              <img
                src={doctorImage}
                alt="Doctor"
                className="w-[260px] md:w-[300px] object-contain"
              />
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="bg-gray-100 p-6 mt-6">
          <div className="flex justify-between flex-wrap items-start">
            <div className="max-w-md">
              <div className="flex items-center gap-3">
                <img src={logo} alt="CureBuddy Logo" className="h-10 w-10 object-contain" />
                <span className="text-2xl font-extrabold text-[#1A1A6C]">CureBuddy</span>
              </div>
              <p className="text-sm text-gray-600 mt-2">
                CureBuddy empowers individuals by simplifying the doctor-patient booking system. With a user-friendly interface and verified professionals, we ensure quality care is just a click away.
              </p>
            </div>
            <div className="mt-4 md:mt-0">
              <h4 className="font-semibold mb-2">Company</h4>
              <ul className="text-sm text-gray-700 space-y-1">
                <li><a href="#">Home</a></li>
                <li><a href="#">About</a></li>
                <li><a href="#">Contact</a></li>
                <li><a href="#">Terms of Service</a></li>
                <li><a href="#">Privacy Policy</a></li>
              </ul>
            </div>
            <div className="mt-4 md:mt-0">
              <h4 className="font-semibold mb-2">Follow Us</h4>
              <div className="flex space-x-4">
                <a href="#"><FaFacebookF className="text-blue-600" /></a>
                <a href="#"><FaTwitter className="text-blue-400" /></a>
                <a href="#"><FaInstagram className="text-pink-500" /></a>
              </div>
            </div>
          </div>
          <p className="text-center text-xs text-gray-500 mt-4">
            &copy; 2025 CureBuddy. All rights reserved.
          </p>
        </footer>
      </>
    );
  };

  export default HomePage;
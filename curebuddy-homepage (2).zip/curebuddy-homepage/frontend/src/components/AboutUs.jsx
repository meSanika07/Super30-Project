import React from "react";
import { Link } from "react-router-dom";
// other imports...


function AboutUs() {
  return (
    <div className="font-sans text-gray-800">
       {/* NAVBAR */}
      <nav className="flex items-center justify-between py-4 px-6 border-b">
        <div className="flex items-center space-x-2">
          <img src="/Logo.jpg" alt="CureBuddy Logo" className="w-6 h-6" />
          <span className="font-bold text-[#1f3bb3] text-lg">CureBuddy</span>
        </div>
        <div className="space-x-6 text-sm">
          {/* Replace all <a> with <Link> */}
          <Link to="/" className="hover:underline">HOME</Link>
          <Link to="/alldoctors" className="hover:underline">ALL DOCTORS</Link>
          <Link to="/about" className="hover:underline">ABOUT</Link>
          <Link to="/contact" className="hover:underline">CONTACT</Link>
        </div>
        <button className="bg-[#1f3bb3] text-white px-4 py-1 text-sm rounded-full">Create account</button>
      </nav>
      {/* Section: About Us Header */}
      <section className="text-center py-10">
        <h2 className="text-3xl font-semibold tracking-wide">ABOUT US</h2>
      </section>

      {/* Section: Welcome and Vision */}
      <section className="flex flex-col md:flex-row items-center gap-10 px-6 md:px-20 mb-16">
        {/* Left Image */}
        <img
  src="/Doctor Team.jpg"
  alt="Doctors"
  className="w-1/3 rounded-xl shadow-lg object-cover"
/>


        {/* Right Text */}
        <div className="md:w-1/2 text-justify">
          <h3 className="text-xl font-bold mb-2">Welcome To CureBuddy</h3>
          <p className="mb-4 leading-relaxed">
            Your Trusted Partner In Managing Your Healthcare Needs Conveniently And Efficiently. At CureBuddy,
            We Understand The Challenges Individuals Face When It Comes To Scheduling Doctor Appointments And
            Monitoring Their Health. That’s Why We’ve Created A Smart, User-Friendly Platform To Simplify Your Healthcare Journey.
          </p>
          <p className="mb-4 leading-relaxed">
            Driven By Our Commitment To Innovation In Healthcare Technology, We Continuously Work To Enhance
            Our Platform By Integrating The Latest Technologies To Improve User Experience And Deliver Top-Tier Service.
            Whether It’s Booking Appointments Or Managing Long-Term Care, CureBuddy Strives To Support Your Wellness Every Step Of The Way.
          </p>

          <h3 className="text-xl font-bold mb-2">Our Vision</h3>
          <p className="leading-relaxed">
            At CureBuddy, Our Vision Is To Build A Seamless, Accessible Healthcare Experience For Every User.
            We Aim To Bridge The Gap Between Patients And Healthcare Providers, Making It Easier For You To Get The Care You Need – Whenever And Wherever You Need It.
          </p>
        </div>
      </section>

      {/* Section: Why Choose Us */}
      <section className="py-10 px-6 md:px-20 bg-white">
        <h3 className="text-center text-2xl font-semibold mb-8">
          WHY <span className="text-blue-600">CHOOSE US</span>
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="border p-6 rounded-lg shadow hover:shadow-md transition">
            <h4 className="font-bold text-lg mb-2">EFFICIENCY</h4>
            <p>Streamlined Appointment Scheduling That Fits Into Your Day, Lifestyle.</p>
          </div>
          <div className="border p-6 rounded-lg shadow hover:shadow-md transition">
            <h4 className="font-bold text-lg mb-2">CONVENIENCE</h4>
            <p>Access To A Network Of Trusted Healthcare Professionals In Your Area.</p>
          </div>
          <div className="border p-6 rounded-lg shadow hover:shadow-md transition">
            <h4 className="font-bold text-lg mb-2">PERSONALIZATION</h4>
            <p>Tailored Recommendations And Reminders To Help You Stay On Top Of Your Health.</p>
          </div>
        </div>
      </section>

      {/* NEW Section: Mission Statement */}
      <section className="bg-blue-50 py-14 px-6 md:px-20 text-center">
        <h3 className="text-2xl font-semibold mb-4">Our Mission</h3>
        <p className="max-w-3xl mx-auto text-lg leading-relaxed">
          We are committed to empowering individuals to take control of their health through technology.
          By building accessible tools, we aim to connect people with the right care at the right time—
          while keeping it simple, secure, and efficient.
        </p>
      </section>
     {/* Footer */}
      <footer className="mt-16 bg-gray-50 text-sm text-gray-600 py-10 px-6 border-t">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          <div>
            <img src="\Logo.jpg" alt="logo" className="h-6 mb-2" />
            <p className="text-gray-500">
              CureBuddy is a simple and secure way to get medical help. Licensed professionals. Easy to use. Affordable for everyone.
            </p>
          </div>
          <div>
            <h5 className="font-semibold text-gray-800 mb-2">Company</h5>
            <ul>
              <li><a href="#">About us</a></li>
              <li><a href="#">Careers</a></li>
              <li><a href="#">Terms</a></li>
              <li><a href="#">Privacy Policy</a></li>
            </ul>
          </div>
          <div>
            <h5 className="font-semibold text-gray-800 mb-2">Get in Touch</h5>
            <p>+91-123-456-7890</p>
            <p>help@curebuddy.com</p>
          </div>
        </div>
       <div className="border-t pt-4 mt-8 text-center text-xs text-gray-500">
  Copyright © 2025 CureBuddy - All Rights Reserved.
</div>
      </footer>
    </div>
  );
}

export default AboutUs;

import React from "react";
import { Link, useLocation } from "react-router-dom";
import { FaUserEdit, FaHospitalAlt, FaFileAlt } from "react-icons/fa";
import { MdContactPhone } from "react-icons/md";
import { BiSolidUserAccount } from "react-icons/bi";

const Sidebar = () => {
  const location = useLocation();

  const navItems = [
  {
    label: "Personal and Contact info",
    path: "/",
    icon: <MdContactPhone />,
  },
  {
    label: "Professional",
    path: "/professional",
    icon: <FaUserEdit />,
  },
  {
    label: "Clinic and Hospital Name",
    path: "/clinic",
    icon: <FaHospitalAlt />,
  },
  {
    label: "Consultation info",
    path: "/consultation",
    icon: <FaUserEdit />,
  },
  {
    label: "Document",
    path: "/document",
    icon: <FaFileAlt />,
  },
  // ❌ Removed Account Setup
];


  return (
    <div className="w-64 bg-white min-h-screen border-r">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-4 border-b">
        <div className="flex items-center space-x-2">
          <img src="/Logo.jpg" alt="Logo" className="w-8 h-8" />
          <h1 className="text-xl font-bold text-blue-700">
            Cure<span className="text-black">Buddy</span>
          </h1>
        </div>
        <span className="px-2 py-1 text-xs border rounded-full">Admin</span>
      </div>

      {/* Navigation */}
      <nav className="p-4 space-y-2">
        {navItems.map((item) => (
          <Link to={item.path} key={item.path}>
            <div
              className={`flex items-center gap-3 px-4 py-2 rounded-md transition-colors ${
                location.pathname === item.path
                  ? "bg-indigo-100 text-indigo-700 font-semibold"
                  : "text-gray-700 hover:bg-gray-100"
              }`}
            >
              <span className="text-lg">{item.icon}</span>
              <span className="text-sm">{item.label}</span>
            </div>
          </Link>
        ))}
      </nav>
    </div>
  );
};

export default Sidebar;

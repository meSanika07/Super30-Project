import React, { useState } from "react";
import Sidebar from "../components/Sidebar";
import Topbar from "../components/Topbar";

const DoctorProfessionalInfoPage = () => {
  const [selectedYear, setSelectedYear] = useState<number | null>(null);
  const [showDropdown, setShowDropdown] = useState(false);

  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 50 }, (_, i) => currentYear - i); // Last 50 years

  const handleSelect = (year: number) => {
    setSelectedYear(year);
    setShowDropdown(false);
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar />

      <div className="flex flex-col flex-1 overflow-hidden">
        <Topbar />

        <main className="p-6 overflow-y-auto">
          <h2 className="text-xl font-semibold mb-4">Professional</h2>

          <div className="bg-white p-6 rounded-lg shadow-md max-w-4xl">
            <form className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold mb-1">Specification</label>
                <input
                  type="text"
                  className="w-full border border-gray-300 rounded px-3 py-2"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold mb-1">University</label>
                <input
                  type="text"
                  className="w-full border border-gray-300 rounded px-3 py-2"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold mb-1">License</label>
                <input
                  type="text"
                  placeholder="License"
                  className="w-full border border-gray-300 rounded px-3 py-2"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold mb-1">Qualification</label>
                <input
                  type="text"
                  className="w-full border border-gray-300 rounded px-3 py-2"
                />
              </div>

              {/* Scrollable Year Dropdown */}
              <div className="md:col-span-2 relative">
                <label className="block text-sm font-semibold mb-1">Year of Experience</label>
                <div
                  className="border border-gray-300 rounded px-3 py-2 bg-white cursor-pointer text-sm"
                  onClick={() => setShowDropdown(!showDropdown)}
                >
                  {selectedYear ? selectedYear : "Select Year"}
                </div>

                {showDropdown && (
                  <div className="absolute z-10 mt-1 w-full max-h-60 overflow-y-auto bg-white border border-gray-300 rounded-md shadow-lg">
                    {years.map((year) => (
                      <div
                        key={year}
                        className="px-4 py-2 hover:bg-blue-100 cursor-pointer text-sm"
                        onClick={() => handleSelect(year)}
                      >
                        {year}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </form>
          </div>
        </main>
      </div>
    </div>
  );
};

export default DoctorProfessionalInfoPage;

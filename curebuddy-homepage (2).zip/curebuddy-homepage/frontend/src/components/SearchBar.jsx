import React from "react";
import { FaMapMarkerAlt, FaSearch } from "react-icons/fa";

const SearchBar = () => {
  const styles = {
    container: {
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      padding: "30px 0", // Adjust vertical spacing as needed
      backgroundColor: "white",
      fontFamily: "Arial, sans-serif",
    },
    searchBar: {
      display: "flex",
      alignItems: "center",
      backgroundColor: "#eaf0ff",
      borderRadius: "12px",
      padding: "15px 25px",
      width: "1150px",
      height: "65px",
      boxSizing: "border-box",
    },
    location: {
      display: "flex",
      alignItems: "center",
      gap: "10px",
      color: "#333",
      fontSize: "16px",
      fontWeight: "500",
    },
    divider: {
      width: "1px",
      height: "30px",
      backgroundColor: "#ccc",
      margin: "0 25px",
    },
    searchInput: {
      display: "flex",
      alignItems: "center",
      flex: 1,
      gap: "10px",
      color: "#333",
    },
    input: {
      border: "none",
      outline: "none",
      background: "transparent",
      fontSize: "16px",
      width: "100%",
      color: "#333",
    },
  };

  return (
    <div style={styles.container}>
      <div style={styles.searchBar}>
        <div style={styles.location}>
          <FaMapMarkerAlt />
          <span>Mumbai</span>
        </div>
        <div style={styles.divider}></div>
        <div style={styles.searchInput}>
          <FaSearch />
          <input
            type="text"
            placeholder="Search doctors,hospital ,etc."
            style={styles.input}
          />
        </div>
      </div>
    </div>
  );
};

export default SearchBar;

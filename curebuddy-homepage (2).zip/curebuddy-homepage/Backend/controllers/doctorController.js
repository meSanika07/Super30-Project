const DoctorProfile = require('../models/DoctorProfile');

// Register Doctor
exports.registerDoctor = async (req, res) => {
  try {
    const {
      userId,
      name,
      email,
      gender,
      dob,
      phone,
      specialization,
      university,
      licenseNo,
      qualification,
      yearsOfExperience,
      hospitalName,
      address,
      city,
      state,
      pincode,
      fee,
      availableDays,
      availableTimeSlots
    } = req.body;

    const files = req.files;

    const doctor = new DoctorProfile({
      userId,
      name,
      email,
      gender,
      dob,
      phone,
      profilePicture: files?.profilePicture?.[0]?.filename || '',

      professionalInfo: {
        specialization,
        university,
        licenseNo,
        qualification,
        yearsOfExperience: Number(yearsOfExperience) || 0
      },

      hospitalInfo: {
        name: hospitalName,
        address,
        city,
        state,
        pincode
      },

      consultationInfo: {
        fee: Number(fee) || 0,
        availableDays: JSON.parse(availableDays || '[]'),
        availableTimeSlots: JSON.parse(availableTimeSlots || '[]')
      },

      documents: {
        degreeCertificate: files?.degreeCertificate?.[0]?.filename || '',
        medicalLicense: files?.medicalLicense?.[0]?.filename || '',
        idProof: files?.idProof?.[0]?.filename || ''
      },

      status: "pending"
    });

    await doctor.save();
    res.status(201).json({ success: true, data: doctor });

  } catch (err) {
    console.error("Doctor Registration Error:", err);
    res.status(500).json({ success: false, message: err.message });
  }
};

// Approve Doctor
exports.approveDoctor = async (req, res) => {
  try {
    const updatedDoctor = await DoctorProfile.findByIdAndUpdate(
      req.params.id,
      { status: 'approved' },
      { new: true }
    );

    if (!updatedDoctor) {
      return res.status(404).json({ success: false, message: 'Doctor not found' });
    }

    res.status(200).json({ success: true, message: 'Doctor approved', data: updatedDoctor });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// Reject Doctor
exports.rejectDoctor = async (req, res) => {
  try {
    const rejectedDoctor = await DoctorProfile.findByIdAndUpdate(
      req.params.id,
      { status: 'rejected' },
      { new: true }
    );

    if (!rejectedDoctor) {
      return res.status(404).json({ success: false, message: 'Doctor not found' });
    }

    res.status(200).json({ success: true, message: 'Doctor rejected', data: rejectedDoctor });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// Get Doctor by ID
exports.getDoctorById = async (req, res) => {
  try {
    const doctor = await DoctorProfile.findById(req.params.id);

    if (!doctor) {
      return res.status(404).json({ success: false, message: "Doctor not found" });
    }

    const baseUrl = `${req.protocol}://${req.get('host')}/uploads/`;
    const formatUrl = (filename) => (filename ? `${baseUrl}${filename}` : null);

    const enrichedDoctor = {
      ...doctor._doc,
      documentInfo: {
        profilePhoto: formatUrl(doctor.profilePicture),
        degreeCertificate: formatUrl(doctor.documents?.degreeCertificate),
        license: formatUrl(doctor.documents?.medicalLicense),
        idProof: formatUrl(doctor.documents?.idProof)
      }
    };

    res.status(200).json({ success: true, data: enrichedDoctor });
  } catch (err) {
    res.status(500).json({ success: false, message: "Server error" });
  }
};

// Get All Doctors
exports.getAllDoctors = async (req, res) => {
  try {
    const doctors = await DoctorProfile.find().sort({ createdAt: -1 });
    res.status(200).json({ success: true, data: doctors });
  } catch (err) {
    res.status(500).json({ success: false, message: "Server error" });
  }
};

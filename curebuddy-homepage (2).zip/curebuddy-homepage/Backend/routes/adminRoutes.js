const express = require('express');
const router = express.Router();
const DoctorProfile = require('../models/DoctorProfile');

// ✅ Get all doctors for admin dashboard
router.get('/doctors', async (req, res) => {
  try {
    const doctors = await DoctorProfile.find().sort({ createdAt: -1 });
    res.status(200).json({ success: true, data: doctors });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed to fetch doctors" });
  }
});

module.exports = router;

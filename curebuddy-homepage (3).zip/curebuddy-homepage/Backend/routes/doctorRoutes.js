const express = require('express');
const router = express.Router();
const upload = require('../middleware/uploadMiddleware');
const {
  registerDoctor,
  approveDoctor,
  rejectDoctor,
  getDoctorById,
  getAllDoctors
} = require('../controllers/doctorController');

// Register a doctor
router.post(
  '/register',
  upload.fields([
    { name: 'profilePicture' },
    { name: 'degreeCertificate' },
    { name: 'medicalLicense' },
    { name: 'idProof' }
  ]),
  registerDoctor
);

// Approve or reject doctor
router.patch('/:id/approve', approveDoctor);
router.patch('/:id/reject', rejectDoctor);

// Get full doctor details by ID
router.get('/:id', getDoctorById);

// Get all doctors
router.get('/', getAllDoctors);

module.exports = router;

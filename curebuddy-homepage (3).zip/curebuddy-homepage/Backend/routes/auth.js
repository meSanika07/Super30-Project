const express = require("express");
const router = express.Router();
const User = require("../models/User");
const jwt = require("jsonwebtoken");
const nodemailer = require("nodemailer");
const bcrypt = require("bcrypt");

// SEND OTP TO PATIENT
router.post("/send-otp", async (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ success: false, message: "Email is required" });

  try {
    const otp = Math.floor(100000 + Math.random() * 900000).toString();

    let user = await User.findOne({ email });
    if (!user) {
      user = new User({ email, role: "patient", fullName: "Patient User", otp });
    } else {
      user.otp = otp;
    }

    await user.save();

    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: process.env.MAIL_USER,
        pass: process.env.MAIL_PASS,
      },
    });

    await transporter.sendMail({
      to: email,
      from: `"eDoc App" <${process.env.MAIL_USER}>`,
      subject: "Your OTP for Login",
      html: `<h2>Your OTP is: ${otp}</h2><p>It is valid for 5 minutes.</p>`,
    });

    res.status(200).json({ success: true, message: "OTP sent to your email" });
  } catch (err) {
    console.error("OTP Send Error:", err.message);
    res.status(500).json({ success: false, message: "Failed to send OTP" });
  }
});

// VERIFY PATIENT OTP
router.post("/verify-otp", async (req, res) => {
  const { email, otp } = req.body;
  if (!email || !otp) {
    return res.status(400).json({ success: false, message: "Email and OTP are required" });
  }

  try {
    const user = await User.findOne({ email, role: "patient" });
    if (!user || user.otp !== otp) {
      return res.status(400).json({ success: false, message: "Invalid OTP" });
    }

    user.otp = null;
    await user.save();

    const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, {
      expiresIn: "7d",
    });

    res.status(200).json({ success: true, token, user });
  } catch (err) {
    res.status(500).json({ success: false, message: "Login failed" });
  }
});

// DOCTOR LOGIN
router.post("/login", async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email, role: "doctor" });
    if (!user || !user.password) {
      return res.status(400).json({ success: false, message: "Invalid credentials" });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ success: false, message: "Invalid credentials" });
    }

    const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, {
      expiresIn: "7d",
    });

    res.status(200).json({ success: true, token, user });
  } catch (err) {
    res.status(500).json({ success: false, message: "Login failed" });
  }
});

// DOCTOR SIGNUP
router.post("/signup", async (req, res) => {
  const { fullName, email, password, role } = req.body;

  if (!fullName || !email || !role) {
    return res.status(400).json({ success: false, message: "All fields are required" });
  }

  if (role === "doctor" && !password) {
    return res.status(400).json({ success: false, message: "Password is required for doctor signup" });
  }

  try {
    const existing = await User.findOne({ email });
    if (existing) {
      return res.status(400).json({ success: false, message: "Email already in use" });
    }

    const hashedPassword = role === "doctor" ? await bcrypt.hash(password, 10) : null;

    const user = new User({
      fullName,
      email,
      password: hashedPassword,
      role,
    });

    await user.save();

    const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, {
      expiresIn: "7d",
    });

    res.status(201).json({ success: true, token, user });
  } catch (err) {
    res.status(500).json({ success: false, message: "Signup failed" });
  }
});

module.exports = router;

import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import DoctorList from "../../components/DoctorList";

const AdminDashboardPage: React.FC = () => {
  const [doctorStats, setDoctorStats] = useState({
    total: 0,
    pending: 0,
    approved: 0,
    rejected: 0,
  });

  const navigate = useNavigate();

  useEffect(() => {
    const fetchDoctorStats = async () => {
      try {
        const res = await fetch("http://localhost:5000/api/admin/doctors");
        const data = await res.json();

        const pending = data.filter((d: any) => d.status === "pending").length;
        const approved = data.filter((d: any) => d.status === "approved").length;
        const rejected = data.filter((d: any) => d.status === "rejected").length;

        setDoctorStats({
          total: data.length,
          pending,
          approved,
          rejected,
        });
      } catch (err) {
        console.error("Failed to fetch doctor stats:", err);
      }
    };

    fetchDoctorStats();
  }, []);

  return (
    <div className="p-8 bg-gray-100 min-h-screen">
      <h1 className="text-3xl font-bold mb-8 text-gray-800">Admin Dashboard</h1>

      {/* Doctor Statistics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded shadow p-6 text-center">
          <h3 className="text-lg font-semibold text-gray-600">Total Doctors</h3>
          <p className="text-3xl font-bold text-blue-600">{doctorStats.total}</p>
        </div>
        <div className="bg-white rounded shadow p-6 text-center">
          <h3 className="text-lg font-semibold text-gray-600">Pending</h3>
          <p className="text-3xl font-bold text-yellow-500">{doctorStats.pending}</p>
        </div>
        <div className="bg-white rounded shadow p-6 text-center">
          <h3 className="text-lg font-semibold text-gray-600">Approved</h3>
          <p className="text-3xl font-bold text-green-600">{doctorStats.approved}</p>
        </div>
        <div className="bg-white rounded shadow p-6 text-center">
          <h3 className="text-lg font-semibold text-gray-600">Rejected</h3>
          <p className="text-3xl font-bold text-red-600">{doctorStats.rejected}</p>
        </div>
      </div>

      {/* Doctor List Table */}
      <div className="bg-white p-6 rounded shadow">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold text-gray-700">All Doctors</h2>
        </div>
        <DoctorList />
      </div>
    </div>
  );
};

export default AdminDashboardPage;

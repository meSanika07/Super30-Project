export const getAllDoctors = async () => {
  const res = await fetch("http://localhost:5000/api/admin/doctors");
  return res.json();
};

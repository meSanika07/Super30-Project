import React from "react";

const PatientDashboardPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-3xl mx-auto bg-white shadow-lg rounded-xl p-8">
        <h1 className="text-3xl font-bold text-blue-700 mb-4">Welcome to CureBuddy 👩‍⚕️</h1>
        <p className="text-gray-700 text-lg">This is your patient dashboard.</p>

        <div className="mt-6 space-y-4">
          <div className="p-4 bg-blue-50 border-l-4 border-blue-500 rounded">
            <p className="text-blue-700 font-semibold">🔍 Browse doctors</p>
            <p className="text-sm text-gray-600">Find the best doctors based on your needs.</p>
          </div>

          <div className="p-4 bg-green-50 border-l-4 border-green-500 rounded">
            <p className="text-green-700 font-semibold">📅 Book appointments</p>
            <p className="text-sm text-gray-600">Manage and view your upcoming bookings.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PatientDashboardPage;

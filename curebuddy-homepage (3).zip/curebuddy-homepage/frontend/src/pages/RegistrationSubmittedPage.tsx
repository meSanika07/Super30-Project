import React from "react";

const RegistrationSubmittedPage: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100 text-center px-4">
      <div className="bg-white p-10 rounded-xl shadow-lg max-w-md w-full">
        <h2 className="text-2xl font-bold text-green-600 mb-4">Registration Submitted ✅</h2>
        <p className="text-gray-700 mb-6">
          Thank you for submitting your profile. Our admin will review and approve your account shortly.
        </p>
        <p className="text-gray-500">We will notify you once approved.</p>
      </div>
    </div>
  );
};

export default RegistrationSubmittedPage;

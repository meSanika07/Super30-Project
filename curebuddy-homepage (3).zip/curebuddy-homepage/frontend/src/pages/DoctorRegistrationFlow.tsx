// ✅ This component controls the full multi-step doctor registration flow

import React, { useState } from "react";
import DoctorAccountSetupPage from "./DoctorAccountSetupPage";
import DoctorPersonalInfoPage from "./DoctorPersonalInfoPage";
import DoctorProfessionalInfoPage from "./DoctorProfessionalInfoPage";
import DoctorClinicHospitalPage from "./DoctorClinicHospitalPage";
import DoctorConsultationPage from "./DoctorConsultationPage";
import DoctorDocumentUploadPage from "./DoctorDocumentUploadPage";

const DoctorRegistrationFlow = () => {
  const [step, setStep] = useState(1);

  const handleNext = () => setStep((prev) => prev + 1);
  const handleBack = () => setStep((prev) => prev - 1);

  return (
    <div className="min-h-screen bg-gray-100">
      {step === 1 && <DoctorAccountSetupPage onNext={handleNext} />}
      {step === 2 && <DoctorPersonalInfoPage onNext={handleNext} onBack={handleBack} />}
      {step === 3 && <DoctorProfessionalInfoPage onNext={handleNext} onBack={handleBack} />}
      {step === 4 && <DoctorClinicHospitalPage onNext={handleNext} onBack={handleBack} />}
      {step === 5 && <DoctorConsultationPage onNext={handleNext} onBack={handleBack} />}
      {step === 6 && <DoctorDocumentUploadPage onBack={handleBack} />}
    </div>
  );
};

export default DoctorRegistrationFlow;

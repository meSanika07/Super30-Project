import React, { useState, ChangeEvent } from "react";
import { useNavigate } from "react-router-dom";
import Sidebar from "../components/Sidebar";
import Topbar from "../components/Topbar";
import DoctorImageUpload from "../components/DoctorImageUpload";
import { useDoctor } from "../context/DoctorContext";

const DoctorPersonalInfoPage = () => {
  const navigate = useNavigate();
  const { updateDoctorData } = useDoctor();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [gender, setGender] = useState("");
  const [dob, setDob] = useState("");
  const [phone, setPhone] = useState("");

  const handlePhoneChange = (e: ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    if (/^\d*$/.test(value)) setPhone(value);
  };

  const handleNext = () => {
    // Save data to global context
    updateDoctorData({ name, email, gender, dob, phone });
    navigate("/professional"); // Navigate to next page
  };

  return (
    <div className="flex h-screen bg-gray-50">
      {/* <Sidebar /> */}

      <div className="flex flex-col flex-1 overflow-hidden">
        <Topbar />

        <main className="p-6 overflow-y-auto">
          <h2 className="text-xl font-semibold mb-4">Personal and Contact Info</h2>

          <div className="bg-white p-6 rounded-lg shadow-md max-w-3xl">
            <DoctorImageUpload />

            <form className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold mb-1">Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full border border-gray-300 rounded px-3 py-2"
                  placeholder="Enter full name"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold mb-1">Phone No.</label>
                <input
                  type="text"
                  value={phone}
                  onChange={handlePhoneChange}
                  className="w-full border border-gray-300 rounded px-3 py-2"
                  maxLength={10}
                  placeholder="Enter phone number"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold mb-1">E-mail</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full border border-gray-300 rounded px-3 py-2"
                  placeholder="Enter email address"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold mb-1">Gender</label>
                <select
                  value={gender}
                  onChange={(e) => setGender(e.target.value)}
                  className="w-full border border-gray-300 rounded px-3 py-2 bg-white text-gray-700"
                >
                  <option value="" disabled>Select Gender</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                </select>
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-semibold mb-1">Date of Birth</label>
                <input
                  type="date"
                  value={dob}
                  onChange={(e) => setDob(e.target.value)}
                  className="w-full border border-gray-300 rounded px-3 py-2"
                />
              </div>
            </form>

            <div className="mt-6 text-right">
              <button
                onClick={handleNext}
                className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 transition"
              >
                Next →
              </button>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default DoctorPersonalInfoPage;

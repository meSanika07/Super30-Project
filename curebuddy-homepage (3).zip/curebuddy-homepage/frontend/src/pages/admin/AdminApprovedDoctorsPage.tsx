import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

interface Doctor {
  _id: string;
  name?: string;
  email?: string;
  phone?: string;
  gender?: string;
  status: string;
}

const AdminApprovedDoctorsPage: React.FC = () => {
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    fetch("http://localhost:5000/api/admin/doctors")
      .then((res) => res.json())
      .then((data) => {
        const approved = (data.data || []).filter((doc: Doctor) => doc.status === "approved");
        setDoctors(approved);
      })
      .catch((err) => console.error("Failed to fetch doctors", err));
  }, []);

  const filteredDoctors = doctors.filter((doc) =>
    `${doc?.name || ""} ${doc?.email || ""}`.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-6 min-h-screen bg-gray-100">
      <h1 className="text-3xl font-bold text-gray-800 mb-6">Approved Doctors</h1>

      <input
        type="text"
        placeholder="Search by name or email..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        className="w-full max-w-lg px-4 py-2 mb-6 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
      />

      <div className="overflow-x-auto bg-white rounded-lg shadow border border-gray-200">
        <table className="min-w-full text-sm text-left">
          <thead className="bg-blue-50 text-blue-700 uppercase text-xs">
            <tr>
              <th className="p-4 border">Name</th>
              <th className="p-4 border">Email</th>
              <th className="p-4 border">Phone</th>
              <th className="p-4 border">Gender</th>
              <th className="p-4 border">Status</th>
            </tr>
          </thead>
          <tbody className="text-gray-700">
            {filteredDoctors.map((doctor, index) => (
              <tr
                key={doctor._id}
                className={`border-b transition ${
                  index % 2 === 0 ? "bg-white" : "bg-gray-50"
                } hover:bg-blue-50`}
              >
                <td
                  className="p-4 font-medium text-blue-600 cursor-pointer border"
                  onClick={() => navigate(`/admin/doctors/${doctor._id}`)}
                >
                  {doctor.name || "N/A"}
                </td>
                <td className="p-4 border">{doctor.email || "N/A"}</td>
                <td className="p-4 border">{doctor.phone || "N/A"}</td>
                <td className="p-4 border">{doctor.gender || "N/A"}</td>
                <td className="p-4 border">
                  <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-semibold">
                    Approved
                  </span>
                </td>
              </tr>
            ))}
            {filteredDoctors.length === 0 && (
              <tr>
                <td colSpan={5} className="text-center p-6 text-gray-500">
                  No approved doctors found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AdminApprovedDoctorsPage;

import React, { useEffect, useState } from "react";
import DoctorList from "../../components/DoctorList";
import {
  Users,
  CheckCircle,
  Clock,
  XCircle,
} from "lucide-react"; // ✅ Lucide Icons

const AdminDashboardPage: React.FC = () => {
  const [allDoctors, setAllDoctors] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");

  useEffect(() => {
    fetch("http://localhost:5000/api/admin/doctors")
      .then((res) => res.json())
      .then((data) => setAllDoctors(data.data || []))
      .catch((err) => console.error("Failed to fetch doctors", err));
  }, []);

  const totalDoctors = allDoctors.length;
  const pendingDoctors = allDoctors.filter((d) => d.status === "pending").length;
  const approvedDoctors = allDoctors.filter((d) => d.status === "approved").length;
  const rejectedDoctors = allDoctors.filter((d) => d.status === "rejected").length;

  const cardClass = `cursor-pointer bg-white p-6 rounded-lg shadow hover:shadow-md border border-gray-200 flex items-center gap-4 transition`;

  const filteredDoctors = allDoctors
    .filter((doc) => filterStatus === "all" || doc.status === filterStatus)
    .filter((doc) =>
      `${doc.name} ${doc.email}`.toLowerCase().includes(searchTerm.toLowerCase())
    );

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white p-6">
      <h1 className="text-4xl font-bold mb-8 text-gray-800">Admin Dashboard</h1>

      {/* Summary Cards with Icons */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
        <div className={cardClass} onClick={() => setFilterStatus("all")}>
          <Users size={32} className="text-blue-600" />
          <div>
            <h3 className="text-sm text-gray-500">Total Doctors</h3>
            <p className="text-2xl font-bold text-blue-600">{totalDoctors}</p>
          </div>
        </div>

        <div className={cardClass} onClick={() => setFilterStatus("pending")}>
          <Clock size={32} className="text-yellow-500" />
          <div>
            <h3 className="text-sm text-gray-500">Pending</h3>
            <p className="text-2xl font-bold text-yellow-500">{pendingDoctors}</p>
          </div>
        </div>

        <div className={cardClass} onClick={() => setFilterStatus("approved")}>
          <CheckCircle size={32} className="text-green-600" />
          <div>
            <h3 className="text-sm text-gray-500">Approved</h3>
            <p className="text-2xl font-bold text-green-600">{approvedDoctors}</p>
          </div>
        </div>

        <div className={cardClass} onClick={() => setFilterStatus("rejected")}>
          <XCircle size={32} className="text-red-500" />
          <div>
            <h3 className="text-sm text-gray-500">Rejected</h3>
            <p className="text-2xl font-bold text-red-500">{rejectedDoctors}</p>
          </div>
        </div>
      </div>

      {/* Filters & Table */}
      <div className="bg-white p-6 rounded-lg shadow border border-gray-200">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6 gap-4">
          <h2 className="text-2xl font-semibold text-gray-700">Doctors List</h2>
          <div className="flex flex-col md:flex-row items-center gap-3">
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="border border-gray-300 px-4 py-2 rounded-md text-sm text-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">All</option>
              <option value="approved">Approved</option>
              <option value="pending">Pending</option>
              <option value="rejected">Rejected</option>
            </select>

            <input
              type="text"
              placeholder="Search by name or email"
              className="border border-gray-300 px-4 py-2 rounded-md w-64 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        {/* Doctor List Table */}
        <DoctorList doctors={filteredDoctors} />
      </div>
    </div>
  );
};

export default AdminDashboardPage;

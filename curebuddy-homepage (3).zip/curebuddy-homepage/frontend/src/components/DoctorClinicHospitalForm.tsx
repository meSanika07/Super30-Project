import React from "react";

function DoctorClinicHospitalForm() {
    return (
        <div className="flex flex-col p-6 bg-white shadow-md rounded-xl w-full mx-auto my-auto min-h-[calc(100vh-80px)]">
            <h2 className="text-2xl font-semibold mb-6 text-gray-800">
                Clinic and Hospital Name
            </h2>

            <label className="text-sm font-medium text-gray-700 mb-1">Hospital name</label>
            <input
                type="text"
                className="mb-4 p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Enter hospital name"
            />
              <label className="text-sm font-medium text-gray-700 mb-1">Contact Number</label>
            <input
                type="number"
                inputMode="numeric"
                pattern="[0-9]*"
                onWheel={(e) => e.currentTarget.blur()}
                className="mb-4 px-5 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm w-80"
                placeholder="Enter Contact Number"
            />

            <label className="text-sm font-medium text-gray-700 mb-1">Address</label>
            <div className="flex gap-4 mb-4">
                <input
                    type="text"
                    className="p-2 border border-gray-300 rounded-md flex-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Address 1"
                />
                <input
                    type="text"
                    className="p-2 border border-gray-300 rounded-md flex-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Address 2"
                />
            </div>
            <label className="text-sm font-medium text-gray-700 mb-1">State</label>
            <input
                type="text"
                className="mb-4 p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Enter State"
            />
            <label className="text-sm font-medium text-gray-700 mb-1">City</label>
            <input
                type="text"
                className="mb-4 p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Enter city"
            />

                     <label className="text-sm font-medium text-gray-700 mb-1">Pincode</label>
            <input
                type="number"
                inputMode="numeric"
                pattern="[0-9]*"
                onWheel={(e) => e.currentTarget.blur()}
                className="mb-4 px-5 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm w-80"
                placeholder="Enter pincode"
            />

        </div>
    );
}

export default DoctorClinicHospitalForm;

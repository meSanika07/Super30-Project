// src/components/AllDoctorsPage.jsx
import React from "react";
import { Link } from "react-router-dom";
import { FiMapPin, FiSearch } from "react-icons/fi";

const doctors = [
  {
    img: "/doctor-profile.jpg",
    name: "Dr. Priya Mehta",
    role: "General physician",
    status: "Available",
  },
  {
    img: "/doctor-profile.jpg",
    name: "Dr. Richard James",
    role: "General physician",
    status: "Available",
  },
  {
    img: "/doctor-profile.jpg",
    name: "Dr. Richard James",
    role: "General physician",
    status: "Available",
  },
  {
    img: "/doctor-profile.jpg",
    name: "Dr. Richard James",
    role: "General physician",
    status: "Available",
  },
  {
    img: "/doctor-profile.jpg",
    name: "Dr. Richard James",
    role: "General physician",
    status: "Available",
  },
  {
    img: "/doctor-profile.jpg",
    name: "Dr. Arjun Verma",
    role: "General physician",
    status: "Available",
  },
  {
    img: "/doctor-profile.jpg",
    name: "Dr. Ramesh Patil",
    role: "General physician",
    status: "Available",
  },
  {
    img: "/doctor-profile.jpg",
    name: "Dr. Vivek Choudhary",
    role: "General physician",
    status: "Available",
  },
  {
    img: "/doctor-profile.jpg",
    name: "Dr. Shreya Nair",
    role: "General physician",
    status: "Available",
  },
  {
    img: "/doctor-profile.jpg",
    name: "Dr. Sandeep Joshi",
    role: "General physician",
    status: "Available",
  },
  {
    img: "/doctor-profile.jpg",
    name: "Dr. Swati Kulkarni",
    role: "General physician",
    status: "Available",
  },
  {
    img: "/doctor-profile.jpg",
    name: "Dr. Nikhil Deshmukh",
    role: "General physician",
    status: "Available",
  },
  {
    img: "/doctor-profile.jpg",
    name: "Dr. Anjali Desai",
    role: "General physician",
    status: "Available",
  },
  {
    img: "/doctor-profile.jpg",
    name: "Dr. Aditya Kapoor",
    role: "General physician",
    status: "Available",
  },
  {
    img: "/doctor-profile.jpg",
    name: "Dr. Richard James",
    role: "General physician",
    status: "Available",
  },
  {
    img: "/doctor-profile.jpg",
    name: "Dr. Richard James",
    role: "General physician",
    status: "Available",
  },
];


const AllDoctorsPage = () => {
  return (
    <div className="py-10 px-4 lg:px-20">
      {/* Header */}
      {/* <header className="flex justify-between items-center px-4 py-4 border-b">
        <div className="flex items-center space-x-1">
          <img src="\Logo.jpg" alt="CureBuddy Logo" className="h-8 w-auto" />
          <span className="text-xl font-bold text-[#1f3bb3]">CureBuddy</span>
        </div> */}
         {/* NAVBAR */}
      <nav className="flex items-center justify-between py-4 px-6 border-b">
        <div className="flex items-center space-x-2">
          <img src="/Logo.jpg" alt="CureBuddy Logo" className="w-6 h-6" />
          <span className="font-bold text-[#1f3bb3] text-lg">CureBuddy</span>
        </div>
        <div className="space-x-6 text-sm">
          {/* Replace all <a> with <Link> */}
          <Link to="/" className="hover:underline">HOME</Link>
          <Link to="/alldoctors" className="hover:underline">ALL DOCTORS</Link>
          <Link to="/about" className="hover:underline">ABOUT</Link>
          <Link to="/contact" className="hover:underline">CONTACT</Link>
        </div>
        <button className="bg-[#1f3bb3] text-white px-4 py-1 text-sm rounded-full">Create account</button>
      </nav>
      {/* </header> */}

      {/* Search Bar */}
      <div className="mt-6 bg-[#edf2fe] rounded-xl flex items-center p-4 gap-4 w-full md:w-[80%] mx-auto">
        <div className="flex items-center gap-4">
          <FiMapPin className="text-xl" />
          <span className="text-sm font-medium">Mumbai</span>
        </div>
        <span className="border-l h-6 border-gray-400"></span>
        <FiSearch className="text-xl" />
        <input
          type="text"
          placeholder="Search doctors, hospital ,etc."
          className="bg-transparent flex-1 outline-none px-2"
        />
      </div>

      {/* Doctor Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 mt-12">
        {doctors.map((doc, i) => (
          <div
            key={i}
            className="bg-white rounded-xl shadow-sm border p-4 text-center hover:shadow-md transition"
          >
            <img
              src={doc.img}
              alt={doc.name}
              className="w-16 h-16 mx-auto rounded-full object-cover"
            />
            <div className="mt-2">
              <p className="text-green-600 text-xs font-semibold">• {doc.status}</p>
              <h4 className="text-sm font-semibold text-gray-800 mt-1">{doc.name}</h4>
              <p className="text-xs text-gray-500">{doc.role}</p>
            </div>
          </div>
        ))}
      </div>
       <div className="my-56"></div>
       {/* Footer */}
      <footer className="mt-16 bg-gray-50 text-sm text-gray-600 py-10 px-6 border-t">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          <div>
            <img src="\Logo.jpg" alt="logo" className="h-6 mb-2" />
            <p className="text-gray-500">
              CureBuddy is a simple and secure way to get medical help. Licensed professionals. Easy to use. Affordable for everyone.
            </p>
          </div>
          <div>
            <h5 className="font-semibold text-gray-800 mb-2">Company</h5>
            <ul>
              <li><a href="#">About us</a></li>
              <li><a href="#">Careers</a></li>
              <li><a href="#">Terms</a></li>
              <li><a href="#">Privacy Policy</a></li>
            </ul>
          </div>
          <div>
            <h5 className="font-semibold text-gray-800 mb-2">Get in Touch</h5>
            <p>+91-123-456-7890</p>
            <p>help@curebuddy.com</p>
          </div>
        </div>
       <div className="border-t pt-4 mt-8 text-center text-xs text-gray-500">
  Copyright © 2025 CureBuddy - All Rights Reserved.
</div>
      </footer>
    </div>
  );
};

export default AllDoctorsPage;

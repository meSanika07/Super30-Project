import React from "react";
import { FaFacebookF, FaTwitter, FaInstagram } from 'react-icons/fa';

import logo from "../assets/Logo.jpg"; // Update the path if needed

const Footer = () => {
  return (
   

<footer className="bg-gray-100 p-6 mt-6">
  <div className="flex justify-between flex-wrap items-start">
    <div className="max-w-md">
      <div className="flex items-center gap-3">
                <img src={logo} alt="CureBuddy Logo" className="h-10 w-10 object-contain" />
                <span className="text-2xl font-extrabold text-[#1A1A6C]">CureBuddy</span>
              </div>
      <p className="text-sm text-gray-600">
        CureBuddy empowers individuals by simplifying the doctor-patient booking system. With a user-friendly interface and verified professionals, we ensure quality care is just a click away.
      </p>
    </div>
    <div className="mt-4 md:mt-0">
      <h4 className="font-semibold mb-2">Company</h4>
      <ul className="text-sm text-gray-700 space-y-1">
        <li><a href="#">Home</a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Contact</a></li>
        <li><a href="#">Terms of Service</a></li>
        <li><a href="#">Privacy Policy</a></li>
      </ul>
    </div>
    <div className="mt-4 md:mt-0">
      <h4 className="font-semibold mb-2">Follow Us</h4>
      <div className="flex space-x-4">
        <a href="#"><FaFacebookF className="text-blue-600" /></a>
        <a href="#"><FaTwitter className="text-blue-400" /></a>
        <a href="#"><FaInstagram className="text-pink-500" /></a>
      </div>
    </div>
  </div>
  <p className="text-center text-xs text-gray-500 mt-4">
    &copy; 2025 CureBuddy. All rights reserved.
  </p>
</footer>

  );
};

export default Footer;

// src/components/DoctorProfilePage.jsx
import React from "react";
import { useParams } from "react-router-dom";
import doctorHero from "/doctor-hero.jpg"; // fallback image

const allDoctors = [
  {
    id: "0",
    name: "Dr. Rajeev Nair",
    specialization: "General Physician",
    experience: "2 Years",
    about:
      "Dr. Nair is committed to preventive medicine and effective treatment strategies.",
    fee: "700",
    image: "/Dr. Rajeev Nair.jpg",
    available: true,
  },
  {
    id: "1",
    name: "Dr. Priya Mehta",
    specialization: "General Physician",
    experience: "3 Years",
    about: "Dr. Mehta emphasizes patient care and long-term wellness.",
    fee: "650",
    image: "/Dr. Priya Mehta.png",
    available: true,
  },
   {
    id: "2",
    name: "Dr. Richard James",
    specialization: "General Physician",
    experience: "3 Years",
    about: "Dr. James emphasizes patient care and long-term wellness.",
    fee: "600",
    image: "/Dr. Richard James.jpeg",
    available: true,
  },
   {
    id: "3",
    name: "Dr. Arjun Verma",
    specialization: "General Physician",
    experience: "3 Years",
    about: "Dr. Verma emphasizes patient care and long-term wellness.",
    fee: "550",
    image: "/Dr. Arjun Verma.jpg",
    available: true,
  },
   {
    id: "4",
    name: "Dr. Ramesh Patil",
    specialization: "General Physician",
    experience: "3 Years",
    about: "Dr. Patil emphasizes patient care and long-term wellness.",
    fee: "500",
    image: "/Dr. Ramesh Patil.jpg",
    available: true,
  },
   {
    id: "5",
    name: "Dr. Vivek Choudhary",
    specialization: "General Physician",
    experience: "3 Years",
    about: "Dr. Choudhary emphasizes patient care and long-term wellness.",
    fee: "650",
    image: "/Dr. Vivek Choudhary.jpg",
    available: true,
  },
   {
    id: "6",
    name: "Dr. Shreya Nair",
    specialization: "General Physician",
    experience: "3 Years",
    about: "Dr. Nair emphasizes patient care and long-term wellness.",
    fee: "700",
    image: "/Dr. Shreya Nair.jpg",
    available: true,
  },
   {
    id: "7",
    name: "Dr. Sandeep Joshi",
    specialization: "General Physician",
    experience: "3 Years",
    about: "Dr. Joshi emphasizes patient care and long-term wellness.",
    fee: "850",
    image: "/Dr. Sandeep Joshi.jpg",
    available: true,
  },
   {
    id: "8",
    name: "Dr. Swati Kulkarni",
    specialization: "General Physician",
    experience: "3 Years",
    about: "Dr. Kulkarni emphasizes patient care and long-term wellness.",
    fee: "550",
    image: "/Dr. Swati Kulkarni.jpg",
    available: true,
  },
  {
    id: "9",
    name: "Dr. Nikhil Deshmukh",
    specialization: "General Physician",
    experience: "3 Years",
    about: "Dr. Deshmukh emphasizes patient care and long-term wellness.",
    fee: "850",
    image: "/Dr. Nikhil Deshmukh.png",
    available: true,
  },
];

const DoctorProfilePage = () => {
  const { id } = useParams(); // ✅ FIXED: using correct param name
  const doctor = allDoctors.find((doc) => doc.id === id);

  if (!doctor) {
    return (
      <div className="text-center mt-10 text-red-600 text-xl">
        ❌ Doctor not found
      </div>
    );
  }

  const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  const dates = ["10", "11", "12", "13", "14", "15", "16"];
  const slots = [
    "8.00 am",
    "8.30 am",
    "9.00 am",
    "9.30 am",
    "10.00 am",
    "10.30 am",
    "11.00 am",
    "11.30 am",
  ];

  return (
    <div className="font-sans min-h-screen bg-white">
      {/* Header */}
      <header className="flex justify-between items-center px-6 py-4 border-b">
        <div className="flex items-center space-x-2">
          <img src="/Logo.jpg" alt="CureBuddy Logo" className="h-8 w-auto" />
          <span className="text-xl font-bold text-[#1f3bb3]">CureBuddy</span>
        </div>
        <nav className="flex items-center space-x-6 text-sm text-black">
          <a href="/" className="hover:underline">HOME</a>
          <a href="/alldoctors" className="hover:underline border-b-2 border-[#1f3bb3] pb-1">ALL DOCTORS</a>
          <a href="/about" className="hover:underline">ABOUT</a>
          <a href="/contact" className="hover:underline">CONTACT</a>
          <button className="ml-4 bg-[#5d6bfa] hover:bg-[#4453d7] text-white px-5 py-1.5 rounded-full text-sm">
            Login / Register
          </button>
        </nav>
      </header>

      {/* Profile Section */}
      <section className="px-6 py-10 max-w-5xl mx-auto">
        <div className="flex flex-col md:flex-row items-start md:space-x-10">
          <img
            src={doctor.image || doctorHero}
            alt={doctor.name}
            className="w-44 h-60 object-cover rounded-xl"
          />
          <div className="mt-6 md:mt-0 flex-1 border rounded-xl p-6">
            <h1 className="text-2xl font-semibold text-black flex items-center">
              {doctor.name}
              <span className="ml-2 w-5 h-5 bg-[#5d6bfa] text-white rounded-full text-xs flex items-center justify-center">✓</span>
            </h1>
            <p className="text-sm text-gray-600 mt-1">
              MBBS - {doctor.specialization}
              <span className="ml-2 px-2 py-0.5 text-xs bg-gray-100 border rounded-full">
                {doctor.experience}
              </span>
            </p>
            <h2 className="mt-5 text-sm font-semibold text-gray-700 flex items-center">
              About <span className="ml-1 text-gray-400 cursor-pointer">ℹ️</span>
            </h2>
            <p className="text-sm text-gray-600 mt-1 leading-relaxed">{doctor.about}</p>
            <p className="mt-4 text-sm text-black font-semibold">
              Appointment fee:{" "}
              <span className="text-[#1f3bb3] font-bold">₹{doctor.fee}</span>
            </p>
          </div>
        </div>

        {/* Booking Slots */}
        <div className="mt-12">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Booking slots</h3>
          <div className="flex flex-wrap gap-4 mb-4">
            {days.map((day, i) => (
              <div
                key={i}
                className={`text-center px-4 py-3 rounded-full border text-sm ${
                  i === 0
                    ? "bg-[#5d6bfa] text-white font-semibold"
                    : "bg-white text-black border-gray-300"
                }`}
              >
                <div>{day}</div>
                <div className="font-bold text-base mt-1">{dates[i]}</div>
              </div>
            ))}
          </div>

          <div className="flex flex-wrap gap-3">
            {slots.map((slot, index) => (
              <button
                key={index}
                className={`px-5 py-2 text-sm border rounded-full ${
                  index === 2
                    ? "bg-[#5d6bfa] text-white"
                    : "bg-white border-gray-300 text-black"
                }`}
              >
                {slot}
              </button>
            ))}
          </div>

          <div className="mt-8">
            <button className="w-full md:w-[300px] bg-[#5d6bfa] hover:bg-[#4453d7] text-white font-semibold py-3 rounded-full shadow-md">
              Book an appointment
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="mt-16 bg-gray-50 text-sm text-gray-600 py-10 px-6 border-t">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          <div>
            <img src="/Logo.jpg" alt="logo" className="h-6 mb-2" />
            <p className="text-gray-500">
              CureBuddy is a simple and secure way to get medical help. Licensed professionals. Easy to use. Affordable for everyone.
            </p>
          </div>
          <div>
            <h5 className="font-semibold text-gray-800 mb-2">Company</h5>
            <ul>
              <li><a href="#">About us</a></li>
              <li><a href="#">Careers</a></li>
              <li><a href="#">Terms</a></li>
              <li><a href="#">Privacy Policy</a></li>
            </ul>
          </div>
          <div>
            <h5 className="font-semibold text-gray-800 mb-2">Get in Touch</h5>
            <p>+91-123-456-7890</p>
            <p>help@curebuddy.com</p>
          </div>
        </div>
        <p className="text-center mt-6 text-xs">Copyright © 2025 CureBuddy. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default DoctorProfilePage;

import React from "react";
import { FaUserPlus } from "react-icons/fa";
import doctorImage from "../assets/image 2222.jpg"; // Adjust the path as needed

const CTASection = () => {
  return (
    <section className="bg-[#586DF6] text-white rounded-xl p-10 mx-4 md:mx-16 my-10">
      <div className="flex flex-col md:flex-row items-center justify-between gap-6">
        {/* Text + Button */}
        <div className="md:w-1/2 text-center md:text-left">
          <h3 className="text-3xl md:text-4xl font-extrabold leading-snug">
            Book Appointment
            <br />
            With 100+ Trusted Doctors
          </h3>
          <button className="mt-6 bg-white text-[#586DF6] px-6 py-3 text-sm md:text-base rounded-full flex items-center gap-2 hover:bg-gray-100 transition">
            <FaUserPlus /> Create account
          </button>
        </div>

        {/* Image */}
        <div className="md:w-1/2 flex justify-center">
          <img
            src={doctorImage}
            alt="Doctor"
            className="w-[260px] md:w-[300px] object-contain"
          />
        </div>
      </div>
    </section>
  );
};

export default CTASection;

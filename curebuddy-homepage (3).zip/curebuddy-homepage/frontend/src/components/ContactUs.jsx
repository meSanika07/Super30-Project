import React from "react";
import { Link } from "react-router-dom";

//import contactImage from "../assets/contact-image.jpg"; // Ensure this exists
import contactImage from "../assets/image 2222.jpg"; // or whatever file you want


const ContactUs = () => {
  return (
    <div className="min-h-screen flex flex-col justify-between bg-white text-gray-800">
      {/* NAVBAR */}
      <nav className="flex items-center justify-between py-4 px-6 border-b">
        <div className="flex items-center space-x-2">
          <img src="/Logo.jpg" alt="CureBuddy Logo" className="w-6 h-6" />
          <span className="font-bold text-[#1f3bb3] text-lg">CureBuddy</span>
        </div>
        <div className="space-x-6 text-sm">
          {/* Replace all <a> with <Link> */}
          <Link to="/" className="hover:underline">HOME</Link>
          <Link to="/alldoctors" className="hover:underline">ALL DOCTORS</Link>
          <Link to="/about" className="hover:underline">ABOUT</Link>
          <Link to="/contact" className="hover:underline">CONTACT</Link>
        </div>
        <button className="bg-[#1f3bb3] text-white px-4 py-1 text-sm rounded-full">Create account</button>
      </nav>


      {/* MAIN CONTENT */}
      <div className="max-w-6xl mx-auto px-6 py-16 flex-grow">
        <h2 className="text-center text-2xl font-semibold mb-12">CONTACT <span className="text-black font-bold">US</span></h2>
        
        <div className="grid md:grid-cols-2 gap-10 items-center">
          <img src={contactImage} alt="Contact" className="rounded-md w-80 shadow-lg" />

          <div className="space-y-6">
            <div>
              <h3 className="font-semibold text-lg">OUR OFFICE</h3>
              <p className="text-sm mt-1">Alandi, Pune, Maharashtra, India – 412105</p>
              <p className="text-sm mt-1">Tel: (+91) 555-0132</p>
              <p className="text-sm mt-1">Email: curebuddy4u@gmail.com</p>
            </div>

            <div>
              <h3 className="font-semibold text-lg">CAREERS AT CUREBUDDY</h3>
              <p className="text-sm mt-1">Learn more about our teams and job openings.</p>
              <button className="mt-2 px-4 py-2 bg-gray-100 border border-gray-400 rounded text-sm hover:bg-gray-200">Explore Doctor</button>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="mt-16 bg-gray-50 text-sm text-gray-600 py-10 px-6 border-t">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          <div>
            <img src="\Logo.jpg" alt="logo" className="h-6 mb-2" />
            <p className="text-gray-500">
              CureBuddy is a simple and secure way to get medical help. Licensed professionals. Easy to use. Affordable for everyone.
            </p>
          </div>
          <div>
            <h5 className="font-semibold text-gray-800 mb-2">Company</h5>
            <ul>
              <li><a href="#">About us</a></li>
              <li><a href="#">Careers</a></li>
              <li><a href="#">Terms</a></li>
              <li><a href="#">Privacy Policy</a></li>
            </ul>
          </div>
          <div>
            <h5 className="font-semibold text-gray-800 mb-2">Get in Touch</h5>
            <p>+91-123-456-7890</p>
            <p>help@curebuddy.com</p>
          </div>
        </div>
       <div className="border-t pt-4 mt-8 text-center text-xs text-gray-500">
  Copyright © 2025 CureBuddy - All Rights Reserved.
</div>
      </footer>
    </div>
  );
};

export default ContactUs;

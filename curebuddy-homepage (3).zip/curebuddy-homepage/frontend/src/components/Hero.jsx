import React from "react";
import { FaArrowRight } from "react-icons/fa";
import heroImage from "../assets/Doctor.png";
// Update path accordingly

const HeroSection = () => {
  return (
    <section className="w-full bg-white px-8 py-20 lg:px-24">
      <div className="flex flex-col lg:flex-row items-center justify-between max-w-7xl mx-auto gap-10">
        
        {/* Left Side: Text and Button */}
        <div className="lg:w-1/2">
          <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6 leading-snug">
            Take Charge Of Your <br /> Health – Book Instantly.
          </h1>
          <p className="text-gray-600 text-base lg:text-lg mb-8">
            Your Health, Your Schedule. Secure Your Appointment Online In Minutes! <br />
            Trusted Care, Seamless Booking – We’re Here When You Need Us Most.
          </p>
          <button className="bg-blue-500 text-white px-20 py-6 rounded-full text-lg font-semibold flex items-center gap-5 hover:bg-blue-600 transition">
            Book appointment <FaArrowRight />
          </button>
        </div>

        {/* Right Side: Image with Fixed Size */}
        <div className="lg:w-1/2 flex justify-center">
          <img
            src={heroImage}
            alt="Healthcare hero"
            className="w-[400px] h-[500px] object-cover rounded-lg shadow-lg"
          />
        </div>
      </div>
    </section>
  );
};

export default HeroSection;

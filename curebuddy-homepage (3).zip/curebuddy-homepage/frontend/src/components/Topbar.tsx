import React from "react";

const Topbar = () => {
  return (
    <header className="flex justify-between items-center bg-white border-b px-6 py-3">
      <img className="h-8" />
      <button className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-1.5 rounded-full text-sm">
        Login
      </button>
    </header>
  );
};

export default Topbar;

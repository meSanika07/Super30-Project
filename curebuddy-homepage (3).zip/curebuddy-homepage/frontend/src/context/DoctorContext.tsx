// src/context/DoctorContext.tsx

import React, { createContext, useContext, useState } from "react";

// ✅ Define full structure for form data (including File types)
interface DoctorData {
  gender: string;
  dob: string;
  phone: string;

  specialization: string;
  university: string;
  licenseNo: string;
  qualification: string;
  yearsOfExperience: number;

  hospitalName: string;
  address: string;
  city: string;
  state: string;
  pincode: string;

  fee: number;
  availableDays: string[];
  availableTimeSlots: string[];

  profilePicture: File | null;
  degreeCertificate: File | null;
  medicalLicense: File | null;
  idProof: File | null;
}

// ✅ Define context shape
interface DoctorContextType {
  doctorData: DoctorData;
  updateDoctorData: (data: Partial<DoctorData>) => void;
}

// ✅ Default values
const defaultDoctorData: DoctorData = {
  gender: "",
  dob: "",
  phone: "",

  specialization: "",
  university: "",
  licenseNo: "",
  qualification: "",
  yearsOfExperience: 0,

  hospitalName: "",
  address: "",
  city: "",
  state: "",
  pincode: "",

  fee: 0,
  availableDays: [],
  availableTimeSlots: [],

  profilePicture: null,
  degreeCertificate: null,
  medicalLicense: null,
  idProof: null,
};

const DoctorContext = createContext<DoctorContextType>({
  doctorData: defaultDoctorData,
  updateDoctorData: () => {},
});

export const DoctorProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [doctorData, setDoctorData] = useState<DoctorData>(defaultDoctorData);

  const updateDoctorData = (newData: Partial<DoctorData>) => {
    setDoctorData((prev) => ({ ...prev, ...newData }));
  };

  return (
    <DoctorContext.Provider value={{ doctorData, updateDoctorData }}>
      {children}
    </DoctorContext.Provider>
  );
};

export const useDoctor = () => useContext(DoctorContext);
